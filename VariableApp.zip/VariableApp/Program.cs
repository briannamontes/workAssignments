﻿//Console.WriteLine("What is your name?");
//Console.ReadLine();

int myVariable = 3000;
double myDouble = 1.50;
bool myBool = true;

string myString = "brianna";
string userName;

Console.WriteLine("your name is " + myString);

Console.WriteLine("What is your name?");
userName = Console.ReadLine();
Console.WriteLine("good morning " + userName);